-- Run this entire script in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  role text not null default 'staff' check (role in ('admin','staff')),
  approved boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.records (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  reference_no text,
  category text not null default 'Other',
  status text not null default 'Active' check (status in ('Active','Semi-active','Archived')),
  record_date date,
  review_date date,
  description text,
  file_path text,
  file_name text,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Create a profile automatically after each signup. New accounts await approval.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id,full_name,email,role,approved)
  values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''),new.email,'staff',false);
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_approved()
returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.profiles where id=auth.uid() and approved=true);
$$;
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.profiles where id=auth.uid() and approved=true and role='admin');
$$;

alter table public.profiles enable row level security;
alter table public.records enable row level security;
create policy "Users can read own profile or admins read all" on public.profiles for select to authenticated
using (id=auth.uid() or public.is_admin());
create policy "Admins update profiles" on public.profiles for update to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "Admins delete profiles" on public.profiles for delete to authenticated
using (public.is_admin());
create policy "Approved users read records" on public.records for select to authenticated
using (public.is_approved());
create policy "Approved users create records" on public.records for insert to authenticated
with check (public.is_approved() and created_by=auth.uid());
create policy "Approved users update records" on public.records for update to authenticated
using (public.is_approved()) with check (public.is_approved());
create policy "Admins delete records" on public.records for delete to authenticated
using (public.is_admin());

-- Private document bucket. 20 MB maximum; adjust MIME types if needed.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('prudence-documents','prudence-documents',false,20971520,
array['application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document',
'application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
'image/jpeg','image/png','text/plain'])
on conflict (id) do nothing;

create policy "Approved users upload their own folder" on storage.objects for insert to authenticated
with check (bucket_id='prudence-documents' and public.is_approved() and (storage.foldername(name))[1]=auth.uid()::text);
create policy "Approved users read documents" on storage.objects for select to authenticated
using (bucket_id='prudence-documents' and public.is_approved());
create policy "Users delete own documents or admins delete any" on storage.objects for delete to authenticated
using (bucket_id='prudence-documents' and public.is_approved() and ((storage.foldername(name))[1]=auth.uid()::text or public.is_admin()));

-- After creating your account, run this once to make that account the first administrator:
-- update public.profiles set role='admin', approved=true where email='YOUR_EMAIL_ADDRESS';
